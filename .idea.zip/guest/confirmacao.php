<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Voto Registrado</title>
    <link rel="stylesheet" href="../css/btn.css">
</head>
<body>
<h1>✅ Voto registrado com sucesso!</h1>
<p>Obrigado por participar da votação.</p>
<center>
    <a class="link-azul" href="../index.php">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" width="16" height="16">
            <path d="M874.7 495.5c0 11.3-9.2 20.5-20.5 20.5H249.4l188.1 188.1c8 8 8 21 0 29-4 4-9.2 6-14.5 6s-10.5-2-14.5-6L185.4 510.6c-3.8-3.8-6-9-6-14.5s2.2-10.6 6-14.5L408.4 258.6c8-8 21-8 29 0s8 21 0 29L249.4 475h604.8c11.3 0 20.5 9.2 20.5 20.5z"/>
        </svg>
        <span>Back</span>
    </a>
</center>
</body>
</html>
